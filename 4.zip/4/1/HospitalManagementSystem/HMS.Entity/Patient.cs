﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.Entity
{
    /// <summary>
    /// Id : 161619
    /// Author: JAndhyala Sravana Kalyani
    /// DoC:17th Oct
    /// Desc: Entity class defined with properties
    /// </summary>
    public class Patient
    {
        public int PatientId { get; set; }
        public DateTime PDandT { get; set; }
        public string PFirstName { get; set; }
        public string PLastName { get; set; }
        public char PGender { get; set; }
        public string PAddress { get; set; }
        public string PState { get; set; }
        public string PCity { get; set; }
        public long PinCode { get; set; }
        public long PContact { get; set; }
    }
}
