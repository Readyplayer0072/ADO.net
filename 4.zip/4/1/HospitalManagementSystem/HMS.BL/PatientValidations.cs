﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS.Entity;
using HMS.Exception;
using HMS.DAL;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace HMS.BL
{
    /// <summary>
    /// Id : 161619
    /// Author: JAndhyala Sravana Kalyani
    /// DoC: 17th Oct
    /// Desc: Patient Details Validation class 
    /// </summary>
    
    public class PatientValidations
    {
        PatientOperations POperations;

        public DataTable GetPatient_BLL()
        {
            DataTable dtPatient;
            try
            {
                POperations = new PatientOperations();
                dtPatient = POperations.GetPatient_DAL();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            return dtPatient;
        }

        public bool validateP(Patient newP)
        {
            bool isValidP = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                if (newP.PLastName == string.Empty && newP.PFirstName == string.Empty
                    && newP.PAddress == string.Empty && newP.PCity == string.Empty &&
                    newP.PState == string.Empty)
                {
                    isValidP = false;
                    sbError.Append("Fields cannot be left empty !!");
                }
                if (newP.PinCode < 100000 || newP.PinCode > 999999)
                {
                    sbError.Append("Pin Code should be 6 digits long\n");
                    isValidP= false;
                }
                if (newP.PContact < 1000000000 || newP.PinCode > 9999999999)
                {
                    sbError.Append("Phone number should start with 7 or 8 or 9 and it should have exactly 10 digits\n");
                    isValidP = false;
                }
                if (!isValidP) throw new PatientException(sbError.ToString());
            }
            catch (PatientException ex)
            { throw ex; }
            catch (SystemException ex)
            {

                throw ex;
            }

            return isValidP;
        }

        public int AddPatient_BLL(Patient newP)
        {
            int rowsAffected = 0;
            PatientOperations operationObj;
            try
            {
                if (validateP(newP))
                {
                    operationObj = new PatientOperations();
                    rowsAffected = operationObj.AddPatient_DAL(newP);
                }
            }
            catch (PatientException ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (SystemException ex)
            {

                throw ex;
            }
            return rowsAffected;

        }
    }
}
