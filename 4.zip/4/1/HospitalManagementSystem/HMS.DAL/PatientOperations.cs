﻿using System.Data;
using System.Data.SqlClient;
using HMS.Entity;
using System.Configuration;
using System;

namespace HMS.DAL
{
    /// <summary>
    /// Id : 161619
    /// Author: JAndhyala Sravana Kalyani
    /// DoC:17th Oct
    /// Desc: Opeartion class defined with properties
    /// </summary>
    public class PatientOperations
    {
        static string PConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        static SqlConnection PConnObj;
        SqlCommand PCommand;
        DataTable dtPatient;
        SqlDataReader PReader = null;
        public PatientOperations()
        {
            PConnObj = new SqlConnection();
            PConnObj.ConnectionString = PConnStr;
        }

        // Adding Patient
        public int AddPatient_DAL(Patient p)
        {
            int rowsAffected = 0;
            try
            {
                PCommand = new SqlCommand("SK.usp_AddPatient", PConnObj);
                PCommand.CommandType = CommandType.StoredProcedure;//,@eLoc,@ePh,@eDeptId
                PCommand.Parameters.AddWithValue("@pDandT", p.PDandT);
                PCommand.Parameters.AddWithValue("@pFName", p.PFirstName);
                PCommand.Parameters.AddWithValue("@pLName", p.PLastName);
                PCommand.Parameters.AddWithValue("@pGemder", p.PGender);
                PCommand.Parameters.AddWithValue("@pAdd", p.PAddress);
                PCommand.Parameters.AddWithValue("@pCity", p.PCity);
                PCommand.Parameters.AddWithValue("@pState", p.PState);
                PCommand.Parameters.AddWithValue("@pPin", p.PinCode);
                PCommand.Parameters.AddWithValue("@pPh", p.PContact);
                PConnObj.Open();
                rowsAffected = PCommand.ExecuteNonQuery();

            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                if (PConnObj.State == ConnectionState.Open) PConnObj.Close();
            }
            return rowsAffected;

        }

        public DataTable GetPatient_DAL()
        {
            try
            {
                dtPatient = new DataTable();
                PCommand = new SqlCommand("SK.usp_DisplayPatient", PConnObj);
                PCommand.CommandType = CommandType.StoredProcedure;
                PConnObj.Open();
                PReader = PCommand.ExecuteReader();
                if (PReader.HasRows)
                {
                    dtPatient.Load(PReader);
                }
            }
            catch (SqlException ex)
            {

                throw;
            }
            catch (Exception ex)
            {

                throw;
            }
            finally
            {
                PReader.Close();
                if (PConnObj.State == ConnectionState.Open) PConnObj.Close();
            }
            return dtPatient;
        }
    }
}
