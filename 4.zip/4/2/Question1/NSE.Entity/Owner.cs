﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NSE.Entity
{
    /// <summary>
    /// Employee ID : 161699
    /// Employee Name : Rajkumar Gupta
    /// Description : This is entity class for the Owner information
    /// Date of Creation : 17-Oct-2018
    /// </summary>
    
    public class Owner
    {
            //Get or set Flat ID
           // public int FlatID { get; set; }
            
            //Get or set Owner First Name
            public string OwnFName { get; set; }
            
            //Get or set Owner Last Name
            public string OwnLName { get; set; }

            //Get or Set Mobile No 
            public long MobileNo { get; set; }

            //Get or set Flat Type
            public int FlatType { get; set; }

            //Get or set Flat Area
            public int FlatArea { get; set; }

            //Get or set Desired Rent Amount
            public int RentAmount { get; set; }

            //Get or set Desired Deposit Amount
            public int DepAmount { get; set; }



    }
}
