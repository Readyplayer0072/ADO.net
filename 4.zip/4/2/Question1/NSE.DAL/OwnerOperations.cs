﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NSE.Entity;
using NSE.Exception;
using System.Data;
using System.Data.SqlClient;

namespace NSE.DAL
{
    /// <summary>
    /// Employee ID : 161699
    /// Employee Name : Rajkumar Gupta
    /// Description : The class for raising Owner specific operations
    /// Date of Creation : 17-Oct-2018
    /// </summary>


    public class OwnerOperations
    {


        //Function to insert Owner record in database
        public static int InsertOwner(Owner own)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "RajkumarG.usp_AddOwner";

                //Adding parameters to command

                cmd.Parameters.AddWithValue("@Own_Fname", own.OwnFName);
                cmd.Parameters.AddWithValue("@Own_Lname", own.OwnLName);
                cmd.Parameters.AddWithValue("@oPh", own.MobileNo);
                cmd.Parameters.AddWithValue("@Ftype", own.FlatType);
                cmd.Parameters.AddWithValue("@Farea", own.FlatArea);
                cmd.Parameters.AddWithValue("@Ramount", own.RentAmount);
                cmd.Parameters.AddWithValue("@Damount", own.DepAmount);


                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
    }
}