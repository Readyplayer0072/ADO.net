﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using NSE.Entity;
using NSE.Exception;
using NSE.DAL;
namespace NSE.BL
{

    /// <summary>
    /// Employee ID : 161699
    /// Employee Name : Rajkumar Gupta
    /// Description : The class for raising Owner Validations
    /// Date of Creation : 17-Oct-2018
    /// </summary>
    

    public class Ownervalidation
    {
    
     
        public static bool ValildateOwner(Owner own)
        {
            bool ownValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //// Last Name Validation
                if (own.OwnFName == String.Empty)
                {
                    ownValidated = false;
                    message.Append("Owner First name should be provided\n");
                }



                // Last Name Validation
                if (own.OwnLName == String.Empty)
                {
                    ownValidated = false;
                    message.Append("Owner Last name should be provided\n");
                }


                // Flat Area Validation
                if (own.FlatArea < 0)
                {
                    ownValidated = false;
                    message.Append("Flat Area should be greater than 0\n");
                }

                //Flat Type Validation
                if (own.FlatType < 0)
                {
                    ownValidated = false;
                    message.Append("Flat Type should be greater than 0\n");
                }

                // Rent Amount Validation
                if (own.RentAmount < 0)
                {
                    ownValidated = false;
                    message.Append("Rent Amount should be greater than 0\n");
                }


                //Deposit Amount Validation
                if (own.DepAmount < own.RentAmount)
                {
                    ownValidated = false;
                    message.Append("Deposit Amount should be greater than Rent Amount\n");
                }


            }  // End of try

            catch (OwnerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return ownValidated;
        }   

        //Method for Insert Owner
        public static int InsertOwner(Owner own)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateOwner(own))
                    recordsAffected = OwnerOperations.InsertOwner(own);
                
                else
                    throw new OwnerException("Please provide valid Owner Information");
            }
            catch (OwnerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        
    }
}

