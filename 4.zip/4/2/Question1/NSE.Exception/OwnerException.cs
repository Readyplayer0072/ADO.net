﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NSE.Exception
{
    /// <summary>
    /// Employee ID : 161699
    /// Employee Name : Rajkumar Gupta
    /// Description : The class for raising Owner spcific exceptions
    /// Date of Creation : 17- Oct-2018
    /// </summary>

    public class OwnerException :ApplicationException
    {
    
    //Default constructor
    public OwnerException()
        : base()
    { }

    //Parameterized constructor with message parameter
    public OwnerException(string message)
        : base(message)
    { }
}
}
