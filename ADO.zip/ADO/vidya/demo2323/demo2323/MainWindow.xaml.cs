﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;            // Step 1
using System.Data;         // For DataTable

namespace Wpf_Connected
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetData();
            GetCount();
        }

        public void GetData()
        {
            using (SqlConnection con = new SqlConnection(@"data source=192.168.14.101\sql2; initial catalog=DemoADO; user id=sa ; password=tvaksa#123 ;"))
            {
                //Step 2

                //using (SqlCommand com = new SqlCommand("Select * from holiday", con))
                using (SqlCommand com = new SqlCommand("getAllEmps", con))
                {
                    com.CommandType = CommandType.StoredProcedure;

                    con.Open();
                    SqlDataReader read = com.ExecuteReader();

                    DataTable dt = new DataTable();
                    dt.Load(read);
                    read.Close();
                    con.Close();
                    dg1.ItemsSource = dt.DefaultView;   // Bind the data  **  ItemsSource propety of datagrid takes data from collection which uses
                                                        // IEnumerable Interface  ** DataView uses that interface

                }

            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(@"data source=192.168.14.101\sql2; initial catalog=DemoADO; user id=sa ; password=tvaksa#123 ;"))
            {
                //Step 2

                // using (SqlCommand com = new SqlCommand("Insert into holiday (id, name,  dept, manager, salary) values(@id,@name, @dept, @manager,@salary)", con))
                using (SqlCommand com = new SqlCommand("insert_emp", con))
                {
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@id", Convert.ToInt16(ID.Text));
                    com.Parameters.AddWithValue("@name", Name.Text); ;

                    com.Parameters.AddWithValue("@manager", Manager.Text);
                    com.Parameters.AddWithValue("@dept", Dept.Text);
                    com.Parameters.AddWithValue("@salary", Convert.ToInt16(Salary.Text));
                    con.Open();
                    int res = com.ExecuteNonQuery();
                    if (res > 0)
                    {
                        MessageBox.Show("Record Inserted");

                    }
                    else
                    {
                        MessageBox.Show("Record Not Inserted");

                    }

                    con.Close();

                }


            }
            GetData();
            GetCount();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(@"data source=192.168.14.101\sql2; initial catalog=DemoADO; user id=sa ; password=tvaksa#123 ;"))
            {
                //Step 2

                //using (SqlCommand com = new SqlCommand("Update Employee  set manager = @manager , dept= @dept, salary = @salary where id = @id", con))
                using (SqlCommand com = new SqlCommand("update_emp", con))

                {
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@id", Convert.ToInt16(ID.Text));

                    com.Parameters.AddWithValue("@manager", Manager.Text);
                    com.Parameters.AddWithValue("@dept", Dept.Text);
                    com.Parameters.AddWithValue("@salary", Convert.ToInt16(Salary.Text));
                    con.Open();
                    int res = com.ExecuteNonQuery();
                    if (res > 0)
                    {
                        MessageBox.Show("Record Updated");

                    }
                    else
                    {
                        MessageBox.Show("Record Not Updated");

                    }
                    con.Close();

                }


            }
            GetData();
            GetCount();
        }

        public void GetCount()
        {
            using (SqlConnection con = new SqlConnection(@"data source=192.168.14.101\sql2; initial catalog=DemoADO; user id=sa ; password=tvaksa#123 ;"))
            {

                //using (SqlCommand com = new SqlCommand("Select count(*) from Employee", con))
                using (SqlCommand com = new SqlCommand("getEmpCount", con))
                {
                    com.CommandType = CommandType.StoredProcedure;

                    SqlParameter p1 = new SqlParameter();
                    p1.ParameterName = "@count";
                    p1.SqlDbType = SqlDbType.Int;
                    p1.Direction = ParameterDirection.ReturnValue;

                    com.Parameters.Add(p1);

                    con.Open();
                    com.ExecuteNonQuery();

                    lblcount.Content = "Number of Employees " + com.Parameters["@count"].Value.ToString();
                    con.Close();
                }
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(@"data source=192.168.14.101\sql2; initial catalog=DemoADO; user id=sa ; password=tvaksa#123 ;"))
            {
                //Step 2

                //using (SqlCommand com = new SqlCommand("Delete from Employee where id=@id", con))
                using (SqlCommand com = new SqlCommand("delete_emp", con))
                {
                    com.CommandType = CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@id", Convert.ToInt16(ID.Text));


                    con.Open();
                    int res = com.ExecuteNonQuery();
                    if (res > 0)
                    {
                        MessageBox.Show("Record Deleted");

                    }
                    else
                    {
                        MessageBox.Show("Record Not Deleted");

                    }
                    con.Close();

                }

            }
            GetData();
            GetCount();
        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(@"data source=192.168.14.101\sql2; initial catalog=DemoADO; user id=sa ; password=tvaksa#123 ;"))
            {
                //Step 2

                //using (SqlCommand com = new SqlCommand("Delete from Employee where id=@id", con))
                using (SqlCommand com = new SqlCommand("getEmpDetails", con))
                {
                    com.CommandType = CommandType.StoredProcedure;


                    SqlParameter p1 = new SqlParameter();
                    p1.ParameterName = "@name";
                    p1.SqlDbType = SqlDbType.VarChar;
                    p1.Size = 20;
                    p1.Direction = ParameterDirection.Output;

                    SqlParameter p2 = new SqlParameter("@dept", SqlDbType.VarChar, 10); ;
                    p2.Direction = ParameterDirection.Output;

                    SqlParameter p3 = new SqlParameter("@manager", SqlDbType.VarChar, 20); ;
                    p3.Direction = ParameterDirection.Output;


                    SqlParameter p4 = new SqlParameter("@salary", SqlDbType.Int);
                    p4.Direction = ParameterDirection.Output;

                    com.Parameters.AddWithValue("@id", Convert.ToInt16(ID.Text));
                    com.Parameters.Add(p1);
                    com.Parameters.Add(p2);

                    com.Parameters.Add(p3);
                    com.Parameters.Add(p4);



                    con.Open();
                    int res = com.ExecuteNonQuery();
                    Name.Text = com.Parameters["@name"].Value.ToString();
                    Dept.Text = com.Parameters["@dept"].Value.ToString();
                    Manager.Text = com.Parameters["@manager"].Value.ToString();
                    Salary.Text = com.Parameters["@salary"].Value.ToString();


                }
            }
        }
    }
}
