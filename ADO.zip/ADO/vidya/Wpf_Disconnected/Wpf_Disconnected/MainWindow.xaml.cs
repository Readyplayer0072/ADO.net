﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Wpf_Disconnected
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window

    { 

    SqlDataAdapter ada;
        DataSet ds;
        SqlCommandBuilder sb;
        SqlConnection con;
        public MainWindow()
    {
        InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
        GetConnection();
        GetData();


    }
    void GetConnection()
    {
        string strConnection = ConfigurationManager.ConnectionStrings["con"].ToString();
        con = new SqlConnection(strConnection);
    }
    void GetData()
    {
        ada = new SqlDataAdapter("Select * from DemoEm", con);
        ds = new DataSet();
        ada.MissingSchemaAction = MissingSchemaAction.AddWithKey;
        ada.Fill(ds, "employee");
        dg1.ItemsSource = ds.Tables[0].DefaultView;
    }

    void Save()
    {
        sb = new SqlCommandBuilder(ada);
        ada.Update(ds, "employee");
        MessageBox.Show("Record saved");
        GetData();
    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {
        GetConnection();
        GetData();
        DataRow dr = ds.Tables[0].NewRow();
        dr[0] = Convert.ToInt16(ID.Text);
        dr[1] = Name.Text;
        dr[2] = Dept.Text;
        dr[3] = Convert.ToInt16(Salary.Text);
        dr[4] = Manager.Text;

        ds.Tables[0].Rows.Add(dr);
        Save();
    }

    private void btnUpdate_Click(object sender, RoutedEventArgs e)
    {
            //SearchEmp();
            GetConnection();
            GetData();
        DataRow dr = ds.Tables[0].Rows.Find(Convert.ToInt16(ID.Text));
        if (dr != null)
        {
            dr["dept"] = Dept.Text;
            dr["salary"] = Convert.ToInt16(Salary.Text);
            dr["manager"] = Manager.Text;
            Save();
        }
        else
        {
            MessageBox.Show("Record not found");
        }
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
        SearchEmp();
        DataRow dr = ds.Tables[0].Rows.Find(Convert.ToInt16(ID.Text));
        if (dr != null)
        {
            ds.Tables[0].Rows.Find(Convert.ToInt16(ID.Text)).Delete();

            Save();
        }
        else
        {
            MessageBox.Show("Record not found");
        }
    }
    void SearchEmp()
    {
        DataRow dr = ds.Tables[0].Rows.Find(Convert.ToInt16(ID.Text));
        if (dr != null)
        {
            Name.Text = dr["name"].ToString();
            Dept.Text = dr["dept"].ToString();
            Salary.Text = dr["salary"].ToString();
            Manager.Text = dr["manager"].ToString();

        }
        else
        {
            MessageBox.Show("Record not found");
        }
    }
    private void Search_Click(object sender, RoutedEventArgs e)
    {
        SearchEmp();

    }

    private void SearchByDept_Click(object sender, RoutedEventArgs e)
    {
        GetConnection();
        GetData();
        foreach (DataRow dr in ds.Tables[0].Rows)
        {
            if (dr["dept"].ToString() == "HR")
            {
                int sal = Convert.ToInt16(dr["salary"]);
                sal += 2000;
                dr["salary"] = sal;
            }
        }
        Save();
        GetData();
    }
}
}


