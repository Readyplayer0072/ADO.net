﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entity;
using Exceptions;
using BusinessLayer;

namespace ProductUI
{
    /// <summary>
    /// Interaction logic for Search.xaml
    /// </summary>
    public partial class Search : Window
    {
        public Search()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ProductBL pb = new ProductBL();
                Product p = pb.Search(int.Parse(txtPid.Text));
                if (p!= null)
                {
                    txtPName.Text = p.ProductName;
                    txtDescp.Text = p.Description;
                    txtUP.Text = p.UnitPrice.ToString();
                    txtSt.Text = p.Stock.ToString();
                    txtCat.Text = p.Category.ToString();
                    gb1.Visibility = Visibility.Visible;
                }
                else
                {
                    gb1.Visibility = Visibility.Hidden;
                    MessageBox.Show
                        (string.Format("Product with id {0} does not exists.",txtPid.Text),
                        "Product Management System");
                }
            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message,"Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Product p = new Product
                {
                    ProductId = int.Parse(txtPid.Text),
                    ProductName = txtPName.Text,
                    Description = txtDescp.Text,
                    UnitPrice = decimal.Parse(txtUP.Text),
                    Stock = int.Parse(txtSt.Text),
                    Category = int.Parse(txtCat.Text)
                };
                ProductBL pb = new ProductBL();
                if (pb.EditProduct(p))
                {
                    gb1.Visibility = Visibility.Hidden;
                    MessageBox.Show("Produt Info Saved.", "Product Management System");
                }
            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {                
                int pid = int.Parse(txtPid.Text);
                ProductBL pb = new ProductBL();
                if (pb.DeleteProduct(pid))
                {
                    gb1.Visibility = Visibility.Hidden;
                    MessageBox.Show("Product Id " + pid + " was deleted.");
                }
            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message, "Product Management System");
            }
        }
    }
}
