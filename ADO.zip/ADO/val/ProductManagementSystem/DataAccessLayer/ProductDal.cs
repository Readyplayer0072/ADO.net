﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DataAccessLayer
{
    public class ProductDal
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="pboj"></param>
        /// <returns></returns>
        static string conStr = string.Empty;
        SqlConnection con = null;
        SqlCommand cmd = null;

        
           
        static ProductDal()
        {
            conStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
           
        }

        public ProductDal()
        {
            con = new SqlConnection(conStr);

        }
        public int AddProduct(Product pboj)
        {
            int pid = 0;
            try
            {
                //con = new SqlConnection();
                //con.ConnectionString = conStr; 
                cmd = new SqlCommand();
                cmd.CommandText = "Geetha.uspAddProduct";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@pId", SqlDbType.Int);
                cmd.Parameters["@pId"].Direction = ParameterDirection.Output;

                cmd.Parameters.AddWithValue("@pName", pboj.ProductName);
                cmd.Parameters.AddWithValue("@descp", pboj.Description);
                cmd.Parameters.AddWithValue("@up", pboj.UnitPrice);
                cmd.Parameters.AddWithValue("@st", pboj.Stock);
                cmd.Parameters.AddWithValue("@cat", pboj.Category);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                pid = int.Parse(cmd.Parameters["@pId"].Value.ToString());
            }
            catch (ProductException) { throw; }
            catch (SqlException )
            {                
                throw;
            }
            catch (SystemException )
            {
                throw ;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return pid;
        }

        public bool EditProduct(Product pboj)
        {
            bool result = false;
            try
            {
               // con = new SqlConnection();
             //   con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Geetha.uspEditProduct";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@pId", pboj.ProductId);
                cmd.Parameters.AddWithValue("@pName", pboj.ProductName);
                cmd.Parameters.AddWithValue("@descp", pboj.Description);
                cmd.Parameters.AddWithValue("@up", pboj.UnitPrice);
                cmd.Parameters.AddWithValue("@st", pboj.Stock);
                cmd.Parameters.AddWithValue("@cat", pboj.Category);

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }
            }
            catch (ProductException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return result;
        }

        public bool DeleteProduct(int productId)
        {
            bool result = false;
                        try
            {
              //  con = new SqlConnection();
               // con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Geetha.uspDeleteProduct";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@pId", productId);                

                con.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                if (noOfRowsAffected == 1)
                {
                    result = true;
                }
            }
            catch (ProductException)
            { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return result;
        }

        public Product Search(int productId)
        {
            Product p = null;
           
            try
            {
              //  con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Geetha.uspSearchProduct";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pId", productId);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    p = new Product
                    {
                        ProductId = int.Parse(dr["ProductId"].ToString()),
                        ProductName = dr["ProductName"].ToString(),
                        Description = dr["Description"].ToString(),
                        UnitPrice = decimal.Parse(dr["Unitprice"].ToString()),
                        Stock = int.Parse(dr["Stock"].ToString()),
                        Category = int.Parse(dr["Category"].ToString())
                    };
                    dr.Close();
                }
            }
            catch (ProductException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return p;
        }

        public DataTable Display()
        {
            DataTable dt = null;
           
            try
            {
               // con = new SqlConnection();
                //con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Geetha.uspGetProducts";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }                
            }
            catch (ProductException) { throw; }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }

        public DataTable GetCategories()
        {
            DataTable dt = null;
            try
            {
               // con = new SqlConnection();
               // con.ConnectionString = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
                cmd = new SqlCommand();
                cmd.CommandText = "Geetha.uspGetCategories";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
            }
            catch (SqlException ex)
            {
                throw new ProductException(ex.Message);
            }
            catch (SystemException ex)
            {
                throw new ProductException(ex.Message);
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            return dt;
        }
    }
}
