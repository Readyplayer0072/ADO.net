﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GatePassApplication.Exceptions
{

    public class GatePassException : ApplicationException
    {
        public GatePassException()
            : base()
        {
        }

        public GatePassException(string message)
            : base(message)
        {
        }
        public GatePassException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
