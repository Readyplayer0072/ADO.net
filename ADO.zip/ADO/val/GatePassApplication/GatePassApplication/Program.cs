﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GatePassApplication.BuisnessLogicLayer;
using GatePassApplication.Entities;
using GatePassApplication.Exceptions;

namespace GatePassApplication
{
    class Program
    {
        static void Main(string[] args)
        {
        

            int choice;
            do
            {
                
        PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddVisitor();
                        break;
                    case 2:
                        SearchVisiorByID();
                        break;
                    case 3:Display();
                        break;
                    case 4:
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;


                }
            } while (choice != -1);

        }
        private static void PrintMenu()
        {
            Console.WriteLine("\n***********Capgemini Gate Pass Application***********");
            Console.WriteLine("1. Add Visitor");

            Console.WriteLine("2. Search Visitor by ID");


            Console.WriteLine("3. Display all visitors");
            Console.WriteLine("4. Exit");
            Console.WriteLine("******************************************\n");

        }
        private static void AddVisitor()
        {
            try
            {

                Visitor newvisitor = new Visitor();

              ;
                Random r = new Random();
                long n =r.Next(1000, 9999);

                string c = "C"+Convert.ToString(n);
                Console.WriteLine("Enter Visitors ID:");
                Console.WriteLine(c);

                newvisitor.GatePassID= c;
                Console.WriteLine("Enter Visitors Name :");
                newvisitor.VisitorsName = Console.ReadLine();
                Console.WriteLine("Enter PhoneNumber :");
                newvisitor.ContactNumber = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Enter ContactPerson name:");
                newvisitor.ContactPerson = Console.ReadLine();
                Console.WriteLine("Enter Date Time in format (mm/dd/year) :");
                newvisitor.DateOfVisit=Convert.ToDateTime(Console.ReadLine());
                Console.WriteLine("Enter PurposeEnter in (Meeting-0 ,Interview-1,Training-2) :");
                int x;
                x = Convert.ToInt32(Console.ReadLine());
               newvisitor.purposeOfVisit = (Visitor.PurposeOfVisit)x ;

                bool visitorAdded= GatePassBLL.AddVisitorBL(newvisitor);
                if (visitorAdded)
                    Console.WriteLine("Visitor Added");
                else
                    Console.WriteLine("Visitor  not Added");
            }
            catch (GatePassException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchVisiorByID()
        {
            try
            {
               
                string searchPassID;
                Console.WriteLine("Enter GuestID to Search:");
                searchPassID = Console.ReadLine();
                Visitor searchVisitor = GatePassBLL.SearchVisitorBL(searchPassID);
                if (searchVisitor != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("VisitorID\t\tName\t\tPhoneNumber\tPurpose\t\tDate of visit");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t{3}\t\t{4}", searchVisitor.GatePassID, searchVisitor.VisitorsName, searchVisitor.ContactNumber,searchVisitor.purposeOfVisit,searchVisitor.DateOfVisit);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No Visitor Details Available");
                }

            }
            catch (GatePassException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void Display()
        {



            try
            {
                List<Visitor> visitorList = GatePassBLL.GetAllVisitor();
                if (visitorList != null)
                {

                    foreach (Visitor visitor in visitorList)
                    {


                        Console.WriteLine("Visitor id: {0}", visitor.GatePassID);
                        Console.WriteLine("Visitor name: {0}", visitor.VisitorsName);
                        Console.WriteLine("Visitor phone no: {0}", visitor.ContactNumber);
                        Console.WriteLine("Visit date: {0}", visitor.DateOfVisit);
                        Console.WriteLine("Visit Purpose: {0}", visitor.purposeOfVisit);
                        Console.WriteLine("contact Person: {0}", visitor.ContactPerson);
                    }
                    
                    //Console.WriteLine("******************************************************************************");
                    //Console.WriteLine("PassID\t\tName\t\tPhoneNumber\t\tpurpose\n");
                    //Console.WriteLine("******************************************************************************");
                    //Console.WriteLine("\t\tDate of visit\t\tContact person");
                    //foreach (Visitor visitor in visitorList)
                    //{
                    //    //Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\n", visitor.GatePassID, visitor.VisitorsName, visitor.ContactNumber,visitor.purposeOfVisit);

                    //    //Console.WriteLine("{0}\t\t{1}", visitor.DateOfVisit, visitor.ContactPerson);
                    //}
                    //Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }
            }
            catch (GatePassException ex)
            {
                Console.WriteLine(ex.Message);
            }





        }




    }
}




        
    

