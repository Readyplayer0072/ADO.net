﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GatePassApplication.Entities
{
        public class Visitor
        {
            private string _GatePassID;
            private string _VisitorsName;
            private DateTime _DateOfVisit;
            private double _ContactNumber;
        private string _ContactPerson;
        
        
        public  enum PurposeOfVisit
        {
            Meeting=0 ,
            Interview=1 ,
            Training=2

        }
        public PurposeOfVisit purposeOfVisit;



        public string  GatePassID
            {
                get { return _GatePassID; }
                set { _GatePassID = value; }
            }


            public string VisitorsName
            {
                get { return _VisitorsName; }
                set { _VisitorsName = value; }
            }

            public double ContactNumber
            {
                get { return _ContactNumber; }
                set { _ContactNumber = value; }
            }

            public DateTime DateOfVisit
            {
                get
                {
                    return _DateOfVisit;
                }
                set
                {
                    _DateOfVisit = value;
                }
            }

        public string ContactPerson { get => _ContactPerson; set => _ContactPerson = value; }

        public Visitor()
            {
                _GatePassID = string.Empty;
                _VisitorsName = string.Empty;
              
                
                _ContactNumber = 0;
            //_PurposeOfVisit = string.Empty;
                

            }


        }
}
