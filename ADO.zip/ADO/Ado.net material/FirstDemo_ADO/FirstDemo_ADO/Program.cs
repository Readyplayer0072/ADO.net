﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;    //  Step 1


namespace FirstDemo_ADO
{
    class Program
    {
        static void Main(string[] args)
        {
            //using (SqlConnection con = new SqlConnection("data source=LAPTOP-53S2KQS8; initial catalog=practice; ; password=;))
            //{
            //     using (SqlCommand com = new SqlCommand("Select * from employee", con))
            //    {
            //        con.Open();
            //        SqlDataReader read = com.ExecuteReader();

            //        if (read.HasRows)
            //        {
            //            while (read.Read())
            //            {
            //                Console.WriteLine(read[0] + "\t" + read[1] + "\t" + read[2] + "\t" + read[3] + "\t" + read[4]);
            //            }
            //        }
            //        else
            //        {
            //            Console.WriteLine("No Records Found");
            //        }
            //        con.Close();
            //        read.Close();
            //    }
            //}

            using (SqlConnection con = new SqlConnection("data source=LAPTOP-53S2KQS8; initial catalog=practice; integrated security=true;"))
            {
                Console.WriteLine("Enter ID");
                int id = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("ENter Name");
                string name = Console.ReadLine();
                Console.WriteLine("Enter Manager");
                string manager = Console.ReadLine();
                Console.WriteLine("Enter Dept");
                string dept = Console.ReadLine();
                Console.WriteLine("Enter Salary"); ;
                int salary = Convert.ToInt16(Console.ReadLine());

                using (SqlCommand com = new SqlCommand("Insert into Employee (id,name, dept, salary, Manager) values(@id, @name,@dept, @salary, @manager )", con))
                {
                    com.Parameters.AddWithValue("@id", id);
                    com.Parameters.AddWithValue("@name", name);
;                    com.Parameters.AddWithValue("@dept", dept);
                    com.Parameters.AddWithValue("@manager", manager);
                    com.Parameters.AddWithValue("@salary", salary);
                    con.Open();
                    com.ExecuteNonQuery();
                    con.Close();
                  
                }
            }

        }
    }
}
