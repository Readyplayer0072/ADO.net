﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BELLayer
{
    public class BEL
    {
        private int id;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }

        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private string manager;

        public string Manager
        {
            get { return manager; }
            set { manager = value; }
        }
        private string dept;

        public string Dept
        {
            get { return dept; }
            set { dept = value; }
        }

        private int salary;

        public int Salary
        {
            get { return salary; }
            set { salary = value; }
        }

    }
}
