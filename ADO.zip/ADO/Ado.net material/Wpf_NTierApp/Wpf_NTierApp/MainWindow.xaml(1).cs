﻿using System.Windows;
using BELLayer;
using BALLayer;
using System;

namespace Wpf_NTierApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        BAL balobject = new BAL();
        BEL belobject = new BEL();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SearchByDept_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dg1.ItemsSource = balobject.getEmps().DefaultView;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            belobject.ID = Convert.ToInt16(ID.Text);
            belobject.Name = Name.Text;
            belobject.Manager = Manager.Text;
            belobject.Dept = Dept.Text;
            belobject.Salary = Convert.ToInt16(Salary.Text);
            if (balobject.insertEmp(belobject) == 1)
            {
                MessageBox.Show("Record inserted");
            }
            dg1.ItemsSource = balobject.getEmps().DefaultView;
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt16(ID.Text);
            // belobject.Name = Name.Text;
            belobject.Manager = Manager.Text;
            belobject.Dept = Dept.Text;
            belobject.Salary = Convert.ToInt16(Salary.Text);
            if (balobject.empUpdate(id, belobject) == 1)
            {
                MessageBox.Show("Record updated");
            }
            dg1.ItemsSource = balobject.getEmps().DefaultView;
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt16(ID.Text);

            if (balobject.empDelete(id) == 1)
            {
                MessageBox.Show("Record deleted");
            }
            dg1.ItemsSource = balobject.getEmps().DefaultView;

        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {

            int id = Convert.ToInt16(ID.Text);
            belobject = balobject.empSearch(id);
            if(belobject!=null)
            {
                Name.Text = belobject.Name;
                ID.Text = belobject.ID.ToString();
                Dept.Text = belobject.Dept;
                Manager.Text = belobject.Manager;
                Salary.Text = belobject.Salary.ToString();

            }
            else
            {
                MessageBox.Show("Record not found");
            }
        }
    }
}