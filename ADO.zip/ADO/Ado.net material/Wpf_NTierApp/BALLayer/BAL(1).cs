﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BELLayer;
using DALLayer;

namespace BALLayer
{
    public class BAL
    {

        DAL dalobject = new DAL();

        public DataTable getEmps()
        {
            DataTable dt = new DataTable();
            dt = dalobject.getEmps();
            return dt;
        }

        public int insertEmp(BEL beobject)
        {
            return dalobject.insertEmp(beobject);
        }
        public int empUpdate(int id, BEL belobject)
        {
            return dalobject.empUpdate(id, belobject);
             
        }


        public int empDelete(int id)
        {
            return dalobject.empDelete(id);

        }


        public BEL empSearch(int id)
        {
            return dalobject.empSearch(id);

        }


    }
}