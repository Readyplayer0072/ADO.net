﻿using System;
using System.Windows;
using System.Data.SqlClient;            // Step 1
using System.Data;         // For DataTable
using System.Configuration;
namespace Wpf_Connected
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetData();
            GetCount();
        }

        public void GetData()
        {
            using (SqlConnection con = new SqlConnection(@"User ID=sa;Password=tvaksa#123;Data Source=192.168.14.101\sql2;Initial Catalog=Demo1;"))
            {
                //Step 2

                using (SqlCommand com = new SqlCommand("Select * from emptab", con))
                {

                    con.Open();
                    SqlDataReader read = com.ExecuteReader();

                    DataTable dt = new DataTable();
                    dt.Load(read);
                    read.Close();
                    con.Close();
                    dg1.ItemsSource = dt.DefaultView;   // Bind the data  **  ItemsSource propety of datagrid takes data from collection which uses
                                                        // IEnumerable Interface  ** DataView uses that interface

                }

            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(@"User ID=sa;Password=tvaksa#123;Data Source=192.168.14.101\sql2;Initial Catalog=Demo1;"))
            {
                //Step 2

                using (SqlCommand com = new SqlCommand("Insert into Employee (id, name,  dept, manager, salary) values(@id,@name, @dept, @manager,@salary)", con))

                {
                    com.Parameters.AddWithValue("@id", Convert.ToInt16(id.Text));
                    com.Parameters.AddWithValue("@name", name.Text); ;
                    com.Parameters.AddWithValue("@manager", manager.Text);
                    com.Parameters.AddWithValue("@dept", dept.Text);
                    com.Parameters.AddWithValue("@salary", Convert.ToInt16(salary.Text));
                    con.Open();
                    int res = com.ExecuteNonQuery();
                    if (res > 0)
                    {
                        MessageBox.Show("Record Inserted");

                    }
                    else
                    {
                        MessageBox.Show("Record Not Inserted");

                    }

                    con.Close();

                }


            }
            GetData();
            GetCount();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(@"User ID=sa;Password=tvaksa#123;Data Source=192.168.14.101\sql2;Initial Catalog=Demo1;"))
            {
                //Step 2

                using (SqlCommand com = new SqlCommand("Update Employee  set manager = @manager , dept= @dept, salary = @salary where id = @id", con))

                {
                    com.Parameters.AddWithValue("@id", Convert.ToInt16(id.Text));

                    com.Parameters.AddWithValue("@manager", manager.Text);
                    com.Parameters.AddWithValue("@dept", dept.Text);
                    com.Parameters.AddWithValue("@salary", Convert.ToInt16(salary.Text));
                    con.Open();
                    int res = com.ExecuteNonQuery();
                    if (res > 0)
                    {
                        MessageBox.Show("Record Updated");

                    }
                    else
                    {
                        MessageBox.Show("Record Not Updated");

                    }
                    con.Close();

                }


            }
            GetData();
            GetCount();
        }

        public void GetCount()
        {
            using (SqlConnection con = new SqlConnection(@"User ID=sa;Password=tvaksa#123;Data Source=192.168.14.101\sql2;Initial Catalog=Demo1;"))
            {

                using (SqlCommand com = new SqlCommand("Select count(*) from Employee", con))
                {
                    con.Open();
                    lblcount.Content = "Number of Employees " + com.ExecuteScalar().ToString();
                    con.Close();
                }
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(@"User ID=sa;Password=tvaksa#123;Data Source=192.168.14.101\sql2;Initial Catalog=Demo1;"))
            {
                //Step 2

                using (SqlCommand com = new SqlCommand("Delete from Employee where id=@id", con))
                {
                    com.Parameters.AddWithValue("@id", Convert.ToInt16(id.Text));


                    con.Open();
                    int res = com.ExecuteNonQuery();
                    if (res > 0)
                    {
                        MessageBox.Show("Record Deleted");

                    }
                    else
                    {
                        MessageBox.Show("Record Not Deleted");

                    }
                    con.Close();

                }

            }
            GetData();
            GetCount();
        }
        private void Search_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection con = new SqlConnection(@"User ID=sa;Password=tvaksa#123;Data Source=192.168.14.101\sql2;Initial Catalog=Demo1;"))
            {
                //Step 2

                //using (SqlCommand com = new SqlCommand("Delete from Employee where id=@id", con))
                using (SqlCommand com = new SqlCommand("getEmpDetails", con))
                {
                    com.CommandType = CommandType.StoredProcedure;


                    SqlParameter p1 = new SqlParameter();
                    p1.ParameterName = "@name";
                    p1.SqlDbType = SqlDbType.VarChar;
                    p1.Size = 20;
                    p1.Direction = ParameterDirection.Output;

                    SqlParameter p2 = new SqlParameter("@dept", SqlDbType.VarChar, 10); ;
                    p2.Direction = ParameterDirection.Output;

                    SqlParameter p3 = new SqlParameter("@manager", SqlDbType.VarChar, 20); ;
                    p3.Direction = ParameterDirection.Output;


                    SqlParameter p4 = new SqlParameter("@salary", SqlDbType.Int);
                    p4.Direction = ParameterDirection.Output;

                    com.Parameters.AddWithValue("@id", Convert.ToInt16(id.Text));
                    com.Parameters.Add(p1);
                    com.Parameters.Add(p2);

                    com.Parameters.Add(p3);
                    com.Parameters.Add(p4);



                    con.Open();
                    int res = com.ExecuteNonQuery();
                    name.Text = com.Parameters["@name"].Value.ToString();
                    dept.Text = com.Parameters["@dept"].Value.ToString();
                    manager.Text = com.Parameters["@manager"].Value.ToString();
                    salary.Text = com.Parameters["@salary"].Value.ToString();


                }
            }
        }



    }
}
      