﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using BELLayer;

namespace DALLayer
{
    public class DAL
    {
        BEL balobject = new BEL();
        SqlConnection con;
        SqlDataAdapter ada;
        DataSet ds;
        SqlCommandBuilder sb;
        void GetConnection()
        {
            //  string strConnection = ConfigurationManager.ConnectionStrings["con"].ToString();

            con = new SqlConnection(@"data source=192.168.14.101\sql2; initial catalog=Demo1;User id=sa;Password=tvaksa#123;");
        }
        public DataTable getEmps()
        {
            GetConnection();
            GetData();
            return ds.Tables["employee"];
        }

        void GetData()
        {
            ada = new SqlDataAdapter("Select * from NewEmpTable", con);
            ds = new DataSet();
            ada.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            ada.Fill(ds, "employee");

        }
        void Save()
        {
            sb = new SqlCommandBuilder(ada);
            ada.Update(ds, "employee");
        }



        public int insertEmp(BEL beobject)
        {
            GetConnection();
            GetData();
            DataRow dr = ds.Tables[0].NewRow();
            dr[0] = beobject.ID;
            dr[1] = beobject.Name;
            dr[2] = beobject.Dept;
            dr[4] = beobject.Salary;
            dr[3] = beobject.Manager;
            ds.Tables[0].Rows.Add(dr);
            Save();
            return 1;

        }
        public int empUpdate(int id, BEL belobject)
        {
            DataRow dr = ds.Tables[0].Rows.Find(id);
            if (dr != null)
            {
                dr["dept"] = belobject.Dept;
                dr["salary"] = belobject.Salary;
                dr["manager"] = belobject.Manager;
                Save();
                return 1;
            }
            else
            {
                return 0;
            }
        }

        public int empDelete(int id)
        {
            DataRow dr = ds.Tables[0].Rows.Find(id);
            if (dr != null)
            {
                ds.Tables[0].Rows.Find(id).Delete();
                Save();
                return 1;
            }
            else
            {
                return 0;
            }
        }

        public BEL empSearch(int id)
        {
            GetConnection();
            GetData();

            BEL beobject = new BEL();
            DataRow dr = ds.Tables[0].Rows.Find(id);
            if (dr != null)
            {
                beobject.ID = id;
                beobject.Name = dr[1].ToString();
                beobject.Dept = dr[2].ToString();
                beobject.Salary =  Convert.ToInt16( dr["salary"]);
                beobject.Manager = dr["manager"].ToString();
                
                return  beobject;
            }
            else
            {
                return null;
            }
        }




    }
}
