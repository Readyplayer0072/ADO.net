﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CustomerService
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, RoutedEventArgs e)
        {
            Sep19CHNEntities obj = new Sep19CHNEntities();
            if (txtRegion.Text != string.Empty)
            {
                var query = from Customer cust in obj.Customers
                                where cust.CustRegion == "mumbai"
                            select cust;
                List<Customer> cList = new List<CustomerService.Customer>();
                cList = query.ToList<Customer>();

                if (cList.Count <= 0)
                {
                    MessageBox.Show("No records Found");
                }
                else
                {
                    dataGrid.ItemsSource = query.ToList();
                }


            }

            else MessageBox.Show("Please enter location");
        }

        
    }
}
