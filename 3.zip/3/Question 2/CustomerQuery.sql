create table Tushar.Customer
(
CustId int identity(1000,1) primary key,
CustName varchar(20),
CustDOB datetime,
CustAddress varchar(50),
CustRegion varchar(20)
)

insert into Tushar.Customer values('jai','12/05/1992','b20 kisan colony','mumbai')

select * from Tushar.Customer