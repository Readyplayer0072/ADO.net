create table Tushar.GharKaKhana
(
CustId int identity(1000,1) primary key,
CustName varchar(20),
CustAddress varchar(50),
CustLandmark varchar(20),
CustCity varchar(20),
CustPincode int,
CustPhoneNo bigint,
CustEmail varchar(20)
)

create proc Tushar.usp_DisplayCustomer		--creating a procedure
as
begin
select * from Tushar.GharKaKhana			--logic inside the procedure
end

exec Tushar.usp_DisplayCustomer

create proc Tushar.usp_AddCustomer
@cName varchar(20),
@cAdd varchar(50),
@cLnd varchar(20),
@cCity varchar(20),
@cPincode int,
@cPh bigint,
@cEmail varchar(20)

as
begin
insert into Tushar.GharKaKhana values(@cName,@cAdd,@cLnd,@cCity,@cPincode,@cPh,@cEmail)
end

exec Tushar.usp_AddCustomer
