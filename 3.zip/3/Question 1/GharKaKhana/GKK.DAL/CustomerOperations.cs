﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Threading.Tasks;
using GKK.Entity;           //Refrence for Entity Class
using System.Data;
using System.Data.SqlClient;


namespace GKK.DAL
{
    /// <summary>
    /// Employee ID : 161697
    /// Employee Name : Tushar Pathak
    /// Description : The class for Customer CRUD Operation
    /// Date of Creation : October 17th 2018
    /// </summary>

    public class CustomerOperations
    {
        static string custConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        static SqlConnection custConnObj;
        SqlCommand custCommand;
        DataTable dtcust;
        SqlDataReader custReader = null;
        public CustomerOperations()
        {
            custConnObj = new SqlConnection();
            custConnObj.ConnectionString = custConnStr;
        }

        public int AddCustomer_DAL(Customer cust)
        {
            int rowsAffected = 0;
            try
            {
                custCommand = new SqlCommand("Tushar.usp_AddCustomer", custConnObj);
                custCommand.CommandType = CommandType.StoredProcedure;
                custCommand.Parameters.AddWithValue("@cName", cust.CustdName);
                custCommand.Parameters.AddWithValue("@cAdd", cust.Address);
                custCommand.Parameters.AddWithValue("@cLnd", cust.Landmark);
                custCommand.Parameters.AddWithValue("@cCity", cust.City);
                custCommand.Parameters.AddWithValue("@cPincode", cust.Pincode);
                custCommand.Parameters.AddWithValue("@cPh", cust.ContactNo);
                custCommand.Parameters.AddWithValue("@cEmail", cust.EmailID);
                custConnObj.Open();
                rowsAffected = custCommand.ExecuteNonQuery();

            }
            catch (SqlException)
            {

                throw;
            }
            catch (SystemException)
            {

                throw;
            }
            finally
            {
                if (custConnObj.State == ConnectionState.Open) custConnObj.Close();
            }
            return rowsAffected;

        }


        public DataTable GetCustomer_DAL()
        {
            try
            {
                dtcust = new DataTable();
                custCommand = new SqlCommand("Tushar.usp_DisplayCustomer", custConnObj);
                custCommand.CommandType = CommandType.StoredProcedure;
                custConnObj.Open();
                custReader = custCommand.ExecuteReader();
                if (custReader.HasRows)
                {
                    dtcust.Load(custReader);
                }
            }
            catch (SqlException)
            {

                throw;
            }
            catch (SystemException)
            {

                throw;
            }
            finally
            {
                custReader.Close();
                if (custConnObj.State == ConnectionState.Open) custConnObj.Close();
            }
            return dtcust;
        }
    }
}
