﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GKK.Entity
{
    public class Customer
    {
        /// <summary>
        /// Employee ID : 161697
        /// Employee Name : Tushar Pathak
        /// Description : This is entity class for the Customer information
        /// Date of Creattion : October 17th 2018
        /// </summary>


        //Get or set Customer ID
        public int CustID { get; set; }

        //Get or set Customer Name
        public string CustdName { get; set; }

        //Get or set Customer Address
        public string Address { get; set; }

        //Get or Set Customer Landmark
        public string Landmark { get; set; }

        //Get or set Customer City
        public string City { get; set; }

        //Get or set Customer Pincode
        public int Pincode { get; set; }

        //Get or set Customer Contact No
        public string ContactNo { get; set; }

        //Get or set Customer Email ID
        public string EmailID { get; set; }
    }
}
