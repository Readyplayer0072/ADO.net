﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GKK.Exception
{
    /// <summary>
    /// Employee ID : 161697
    /// Employee Name : Tushar Pathak
    /// Description : The class for raising Customer specific exceptions
    /// Date of Creation : October 17th 2018
    /// </summary>

    public class CustomerException : ApplicationException
    {
        //Default constructor
        public CustomerException()
            : base()
        { }

        //Parameterized constructor with message parameter
        public CustomerException(string message)
            : base(message)
        { }

    }
}
